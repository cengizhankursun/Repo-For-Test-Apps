let ad="Mehmet";
let yas=30;
let aktifMi=true;

console.log(ad, yas, aktifMi);

console.log(typeof ad, typeof yas, typeof aktifMi);

function selamVer(isim) {
  console.log("Merhaba  " + isim + "!");  
} 
selamVer("Mehmet");

let ogrenci = {
  ad: "Mehmet",
  yas: 30,
  aktifMi: true,
 
};

console.log(ogrenci.ad, ogrenci.yas, ogrenci.aktifMi);

ogrenci.bolum = "Matematik";
console.log(ogrenci.bolum);

const araba = {
  marka: "Toyota",
  model: "Corolla",
  yil: 2020,
  renk: "Kırmızı",
  motorHacmi: 1.6,
  fiyat: 1300000,
};


function arabaBilgileriniYazdir(araba) {
  console.log("Araba Bilgileri:");
  console.log("Marka: " + araba.marka);
  console.log("Model: " + araba.model);
  console.log("Yıl: " + araba.yil);
  console.log("Renk: " + araba.renk);
  console.log("Motor Hacmi: " + araba.motorHacmi + "L");
  console.log("Fiyat: " + araba.fiyat + " TL");
};
arabaBilgileriniYazdir(araba);