const araba = {
    marka: "Toyota",
    model: "Corolla",
    yil: 2020,
//     renk: "Kırmızı",
//     motorHacmi: 3.0,
//     beygirGucu: 300,
//     fiyat: 500000,
//
 };

console.log(araba.marka); // Toyota

let a = "model";
console.log(araba[a]); // Corolla

araba.renk = "Kırmızı"; // Yeni özellik ekleme
console.log(araba);; // { marka: 'Toyota', model: 'Corolla', yil: 2020, renk: 'Kırmızı' }

araba.yil = 2023; // Mevcut özelliği güncelleme

console.log(araba);

delete araba.model; // Özelliği silme
console.log(araba); // { marka: 'Toyota', yil: 2023, renk: 'Kırmızı' }


const ogrenci = {
    ad: "Ahmet",
    soyad: "Yılmaz",
    yas: 20,
        tamAd: function() {
        return this.ad + " " + this.soyad;
    },
    selamla: function() {
        console.log("Merhaba, ben " + this.tamAd() + "," + " Benim yaşım " + this.yas + ".");
    }
};

console.log(ogrenci.tamAd()); // Ahmet Yılmaz
ogrenci.selamla(); // Merhaba, ben Ahmet Yılmaz , Benim yaşım 20.

const film = { 
    ad:"Inception",
    yonetmen: "Christopher Nolan",
    sure: 148,
};

for (let ozellik in film) {
    console.log(ozellik + ": " + film[ozellik]);
}



function person(isim, soyad, yas, meslek) {
    this.isim = isim;
    this.soyad = soyad;
    this.yas = yas;
    this.meslek = meslek;
    this.bilgiGoster = function() {
        console.log("Merhaba, ben " + this.isim + " " + this.soyad + ", " + this.yas + " yaşındayım ve " + this.meslek + "yim.");
    };
    console.log("Merhaba, ben " + isim + " " + soyad + ", " + yas + " yaşındayım ve " + meslek + "yim.");
    this.kontrolEt = function() {
        if (yas < 18) {
            console.log("Bu kişi reşit değil.");
        } else if (yas >= 18 && yas < 30) {
            console.log("Bu kişi genç bir yetişkin.");
        } else if (yas >= 30 && yas < 50) {
            console.log("Bu kişi orta yaşlı bir yetişkin.");
        } else {
            console.log("Bu kişi yaşlı bir yetişkin.");
        }
    }
    this.kontrolEt();
}

let kisi1 = new person("Ali", "Kara", 25, "Yazılım Geliştirici");
let kisi2 = new person("Ayşe", "Demir", 30, "Grafik Tasarımcı");
let kisi3 = new person("Mehmet", "Yılmaz", 28, "Proje Yöneticisi");
let kisi4 = new person("Fatma", "Kaya", 22, "Pazarlama Uzmanı");
let kisi5 = new person("Emre", "Çelik", 17, "Öğrenci");




